package com.hkshenoy.jaltantraloopsb.optimizer;

public enum Formulation {
	PARALLEL_LINK, DISCRETE_SEGMENT, RE_SOLVING

}
