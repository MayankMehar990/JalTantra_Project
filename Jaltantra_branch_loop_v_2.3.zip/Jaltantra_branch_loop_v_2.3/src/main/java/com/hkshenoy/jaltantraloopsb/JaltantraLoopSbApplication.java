package com.hkshenoy.jaltantraloopsb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JaltantraLoopSbApplication {

    public static void main(String[] args) {
        SpringApplication.run(JaltantraLoopSbApplication.class, args);
    }

}
