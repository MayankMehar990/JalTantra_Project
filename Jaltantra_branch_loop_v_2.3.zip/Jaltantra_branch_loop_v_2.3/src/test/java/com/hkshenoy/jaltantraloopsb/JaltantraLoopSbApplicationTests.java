package com.hkshenoy.jaltantraloopsb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JaltantraLoopSbApplicationTests {

    @Test
    void contextLoads() {
    }

}
